package de.unibremen.informatik.tdki.bl2020;

public class NotInELNormalFormException extends Exception {

    public NotInELNormalFormException(String message) {
        super(message);
    }

}

